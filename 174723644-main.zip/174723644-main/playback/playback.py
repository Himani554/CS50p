write = input()
playback = write.replace(" ","...")
print(playback)
