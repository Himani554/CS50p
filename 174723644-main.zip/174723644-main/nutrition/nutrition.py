f = input("Item: ").lower().strip()

if f == "apple":
    print("Calories: 130")
elif f == "avocado":
    print("Calories: 50")
elif f == "banana":
    print("Calories: 110")
elif f == "cantaloupe":
    print("Calories: 50")
elif f == "grapefruit":
    print("Calories: 60")
elif f == "grapes":
    print("Calories: 90")
elif f == "honeydew melon":
    print("Calories: 50")
elif f == "kiwifruit":
    print("Calories: 90")
elif f == "lemon":
    print("Calories: 15")
elif f == "lime":
    print("Calories: 20")
elif f == "nectarine":
    print("Calories: 60")
elif f == "orange":
    print("Calories: 80")
elif f == "peach":
    print("Calories: 60")
elif f == "pear":
    print("Calories: 100")
elif f == "pineapple":
    print("Calories: 50")
elif f == "plums":
    print("Calories: 70")
elif f == "strawberries":
    print("Calories: 50")
elif f == "sweet cherries":
    print("Calories: 100")
elif f == "tangerine":
    print("Calories: 50")
elif f == "Watermelon":
    print("Calories: 80")
else:
    print()
