m = int(input("Mass(in kilograms): "))
c = 300000000
e = m*c*c
print(f"Energy: {e}")
