write = input()
print(write.lower())
