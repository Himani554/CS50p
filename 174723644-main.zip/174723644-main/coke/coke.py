def main():
    amountDue = print("Amount Due: 50")
    i = 50
    while i > 0:
        amountdue = amount(i)
        if amountdue > 0:
            print(f"Amount Due:",amountdue)
        else:
            print("Change Owed:",-amountdue)
        i = amountdue

def amount(n):
    insertCoin = int(input("Insert Coin: "))
    if insertCoin == 25:
        return n - 25
    elif insertCoin == 10:
        return n - 10
    elif insertCoin == 5:
        return n - 5
    else:
        return n

main()


