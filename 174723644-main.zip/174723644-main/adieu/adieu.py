import inflect

p = inflect.engine()
names=[]


while True:
    try:
        name = input("Name: ").strip()
        names.append(name)
    except EOFError:
        print()
        break
output = p.join(names)
print("Adieu, adieu, to",output)


